from multiprocessing import Process, Queue
import time
import random


# Function to simulate image resizing with error handling
def resize_image(input_queue, output_queue):
    while not input_queue.empty():
        image_path = input_queue.get()
        try:
            # Simulating random failure for image resizing
            if random.choice([True, False]):  # 50% chance of failure
                raise Exception("Failed to resize image.")

            # Simulated resizing operation
            time.sleep(1)  # Simulate processing time
            output_queue.put(f"{image_path} resized")

        except Exception as e:
            output_queue.put(f"Error processing {image_path}: {str(e)}")


if __name__ == "__main__":
    input_queue = Queue()
    output_queue = Queue()

    # Simulated image paths
    image_paths = [f"image_{i}.jpg" for i in range(5)]

    # Fill the input queue
    for path in image_paths:
        input_queue.put(path)

    # Measure the time taken to process images
    start_time = time.time()  # Start time

    # Creating and starting processes
    processes = [Process(target=resize_image, args=(input_queue, output_queue)) for _ in range(3)]

    for p in processes:
        p.start()

    for p in processes:
        p.join()

    end_time = time.time()  # End time

    # Collect resized images or errors
    resized_images = []
    while not output_queue.empty():
        resized_images.append(output_queue.get())

    # Display the results
    print("Resized images and errors:", resized_images)
    print(f"Time taken to process all images: {end_time - start_time} seconds")
