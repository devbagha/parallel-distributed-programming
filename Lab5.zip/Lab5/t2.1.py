from multiprocessing import Process, Manager, Lock

# Function to compute the sum of a range and add to the shared list
def add_sum_to_list(shared_list, lock, numbers):
    total_sum = sum(numbers)  # Compute the sum of the range
    with lock:
        shared_list.append(total_sum)  # Add the computed sum to the shared list

if __name__ == "__main__":
    manager = Manager()
    shared_list = manager.list()
    lock = Lock()

    # List of number ranges
    numbers_to_add = [range(5), range(5, 10), range(10, 15)]

    # Creating and starting processes
    processes = [Process(target=add_sum_to_list, args=(shared_list, lock, numbers)) for numbers in numbers_to_add]

    for p in processes:
        p.start()

    for p in processes:
        p.join()

    print("Shared list (sums) after all processes using multiprocessing:", list(shared_list))
