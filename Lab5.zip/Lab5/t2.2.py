from concurrent.futures import ProcessPoolExecutor
from multiprocessing import Manager

# Function to compute the sum of a range
def compute_sum(numbers):
    return sum(numbers)

if __name__ == "__main__":
    manager = Manager()
    shared_list = manager.list()  # Using a manager to store results

    numbers_to_add = [range(5), range(5, 10), range(10, 15)]

    # Using ProcessPoolExecutor to compute the sums
    with ProcessPoolExecutor() as executor:
        # Map the function to the number ranges and get results
        results = list(executor.map(compute_sum, numbers_to_add))

    # Store the results in the shared list
    shared_list.extend(results)

    print("Shared list (sums) after all processes using ProcessPoolExecutor:", list(shared_list))
