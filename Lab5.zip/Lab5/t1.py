from multiprocessing import Pool
import requests
import time

# Function to fetch URL with error handling
def fetch_url(url):
    try:
        response = requests.get(url)
        return url, response.status_code
    except requests.RequestException as e:
        # Return error message if the request fails
        return url, f"Error: {str(e)}"

if __name__ == "__main__":
    urls = [
        'https://example.com',
        'https://python.org',
        'https://github.com',
        'https://pypi.org',
        # Add more URLs if needed
    ]

    # Measure time before applying async calls
    start_time = time.time()  # Start time before the async calls

    # Using Pool to manage parallel requests
    with Pool(processes=4) as pool:
        # Use apply_async for asynchronous requests
        async_results = [pool.apply_async(fetch_url, (url,)) for url in urls]

        # Measure time after all async calls are initiated
        apply_async_end_time = time.time()

        # Collecting the results asynchronously
        for result in async_results:
            url, status = result.get()  # Get result asynchronously
            print(f"URL: {url}, Status Code: {status}")

    end_time = time.time()  # End time after all results are collected

    # Measuring the total time taken
    print(f"Time taken to initiate all async calls: {apply_async_end_time - start_time} seconds")
    print(f"Total time taken to complete all requests: {end_time - start_time} seconds")
